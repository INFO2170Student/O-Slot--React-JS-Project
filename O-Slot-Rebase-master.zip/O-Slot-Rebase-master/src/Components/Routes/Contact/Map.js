

const ContactMap = () => {

    return(
        <div class="mapouter"><div class="gmap_canvas"><iframe title="myFrame" width="600" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=130%20dundas%20street,%20London,%20On&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div></div>
    )
}

export default ContactMap;